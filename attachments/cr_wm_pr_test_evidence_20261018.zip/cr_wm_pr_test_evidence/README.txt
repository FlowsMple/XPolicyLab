CR-WM PR test evidence, 2026-10-18

Use the outer PR_DESCRIPTION.md for the PR body and attach this evidence ZIP; PR_TESTING.txt is a supplementary test guide.
logs/: four full final eval.sh/WebSocket transcripts; logs/history/: two resolved earlier failures.
executed_commands.json: recorded commands/environments and original-report/log hash bindings.
log_manifest.json and REDACTION_NOTICE.txt: public-copy transformations and both raw/public SHA256 values.
test_summary.json: exact scope and results of the four finite interface tests.
results/: actual simulator result files, each one trial.
native_benchmark_summary.json and native_full_results.txt: separately labelled 10,000-trial native benchmark.
policy_identity.json: tested code/weight identity and exact asset-only line-ending repair.
static_checks.json: shell syntax and model/deploy compilation checks; no inference rerun.
official_requirements.json: official guideline and PR-template sources checked for this evidence task.

Public copies preserve event order and outcomes with the capacity redactions declared in REDACTION_NOTICE.txt. Private original transcripts are retained separately and are not part of this archive. This evidence bundle contains no weights, secrets, private path mapping or standalone EEF sidecar assets.
